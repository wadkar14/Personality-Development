from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import PersonalityForm
import joblib
import numpy as np
import os

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'ml_model', 'best_model.pkl')
SCALER_PATH = os.path.join(os.path.dirname(__file__), 'ml_model', 'scaler.pkl')

model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

PERSONALITY_INFO = {
    'Introvert': {
        'description': 'You are an Introvert! You recharge by spending time alone and prefer deep, meaningful conversations over large social gatherings. You are thoughtful, reflective, and highly creative.',
        'traits': ['Thoughtful & Reflective', 'Prefers Small Groups', 'Deep Thinker', 'Independent', 'Creative'],
        'color': '#6c63ff',
        'emoji': '🧠',
    },
    'Extrovert': {
        'description': 'You are an Extrovert! You gain energy from social interactions and love being around people. You are outgoing, enthusiastic, and thrive in group settings.',
        'traits': ['Outgoing & Energetic', 'Loves Social Events', 'Natural Leader', 'Enthusiastic', 'Expressive'],
        'color': '#ff6584',
        'emoji': '🌟',
    },
    'Ambivert': {
        'description': 'You are an Ambivert! You have a balance of both introverted and extroverted traits. You adapt easily to different social situations and enjoy both solitude and socializing.',
        'traits': ['Adaptable', 'Balanced Social Life', 'Flexible', 'Empathetic', 'Versatile'],
        'color': '#43b89c',
        'emoji': '⚖️',
    },
}

def home(request):
    return render(request, 'dashboard.html')

@login_required(login_url='/login/')
def predict(request):
    form = PersonalityForm()
    if request.method == 'POST':
        form = PersonalityForm(request.POST)
        if form.is_valid():
            features = [int(form.cleaned_data[f'feature_{i}']) for i in range(1, 31)]
            features_array = np.array(features).reshape(1, -1)
            features_scaled = scaler.transform(features_array)
            prediction = model.predict(features_scaled)[0]
            probabilities = model.predict_proba(features_scaled)[0]
            classes = model.classes_
            prob_dict = {cls: round(float(prob) * 100, 1) for cls, prob in zip(classes, probabilities)}
            info = PERSONALITY_INFO.get(prediction, {})
            return render(request, 'result.html', {
                'prediction': prediction,
                'probabilities': prob_dict,
                'info': info,
            })
    return render(request, 'prediction_form.html', {'form': form, 'rating_range': range(1, 11)})

def register_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 != password2:
            messages.error(request, 'Passwords do not match.')
        elif User.objects.filter(username=username).exists():
            messages.error(request, 'Username already taken.')
        else:
            user = User.objects.create_user(username=username, email=email, password=password1)
            login(request, user)
            messages.success(request, f'Welcome, {username}!')
            return redirect('home')
    return render(request, 'register.html')

def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('predict')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')
