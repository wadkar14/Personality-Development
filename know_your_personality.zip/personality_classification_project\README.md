# Personality Type Classification Project

A Django + Machine Learning major project for classifying personality into Introvert, Extrovert, and Ambivert.

## Run
```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```
