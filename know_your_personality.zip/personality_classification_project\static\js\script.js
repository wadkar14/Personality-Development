// ===== Progress bar for prediction form =====
function updateProgress() {
    const selects = document.querySelectorAll('.question-select');
    if (!selects.length) return;
    let answered = 0;
    selects.forEach(sel => {
        const card = sel.closest('.question-card');
        if (sel.value) {
            answered++;
            card && card.classList.add('answered');
        } else {
            card && card.classList.remove('answered');
        }
    });
    const pct = Math.round((answered / selects.length) * 100);
    const fill = document.getElementById('progressFill');
    const label = document.getElementById('progressLabel');
    if (fill) fill.style.width = pct + '%';
    if (label) label.textContent = answered + ' / ' + selects.length + ' answered (' + pct + '%)';
}

document.addEventListener('DOMContentLoaded', function () {
    // Attach change listeners to all question selects
    document.querySelectorAll('.question-select').forEach(sel => {
        sel.addEventListener('change', updateProgress);
    });
    updateProgress();

    // Animate progress bars on result page
    document.querySelectorAll('.progress-bar[data-width]').forEach(bar => {
        setTimeout(() => {
            bar.style.width = bar.getAttribute('data-width') + '%';
        }, 300);
    });

    // Password strength indicator
    const pw = document.getElementById('password1');
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');
    if (pw && strengthBar) {
        pw.addEventListener('input', function () {
            const val = pw.value;
            let score = 0;
            if (val.length >= 8) score++;
            if (/[A-Z]/.test(val)) score++;
            if (/[0-9]/.test(val)) score++;
            if (/[^A-Za-z0-9]/.test(val)) score++;
            const levels = ['', 'Weak', 'Fair', 'Good', 'Strong'];
            const colors = ['', '#e74c3c', '#f39c12', '#3498db', '#27ae60'];
            const widths = ['0%', '25%', '50%', '75%', '100%'];
            strengthBar.style.width = widths[score];
            strengthBar.style.background = colors[score];
            if (strengthText) strengthText.textContent = score > 0 ? levels[score] : '';
        });
    }

    // Confirm password match
    const pw2 = document.getElementById('password2');
    const matchMsg = document.getElementById('matchMsg');
    if (pw && pw2 && matchMsg) {
        pw2.addEventListener('input', function () {
            if (pw2.value === '') { matchMsg.textContent = ''; return; }
            if (pw2.value === pw.value) {
                matchMsg.textContent = '✓ Passwords match';
                matchMsg.style.color = '#27ae60';
            } else {
                matchMsg.textContent = '✗ Passwords do not match';
                matchMsg.style.color = '#e74c3c';
            }
        });
    }

    // Auto-dismiss alerts after 4s
    document.querySelectorAll('.alert').forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 4000);
    });
});
