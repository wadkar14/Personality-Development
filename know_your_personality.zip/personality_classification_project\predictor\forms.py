from django import forms

SCALE_CHOICES = [(str(i), str(i)) for i in range(1, 11)]

FEATURE_LABELS = [
    "How sociable are you at parties? (1=Very shy, 10=Very outgoing)",
    "How much do you enjoy meeting new people? (1=Not at all, 10=Love it)",
    "How often do you prefer working alone? (1=Never, 10=Always)",
    "How energized do you feel in large groups? (1=Drained, 10=Energized)",
    "How much do you enjoy deep one-on-one conversations? (1=Dislike, 10=Love)",
    "How often do you initiate conversations? (1=Rarely, 10=Always)",
    "How comfortable are you with public speaking? (1=Very uncomfortable, 10=Very comfortable)",
    "How much do you need alone time to recharge? (1=Not at all, 10=Very much)",
    "How adventurous are you in social situations? (1=Not adventurous, 10=Very adventurous)",
    "How often do you attend social events? (1=Rarely, 10=Very often)",
    "How much do you enjoy being the center of attention? (1=Dislike, 10=Love)",
    "How easily do you open up to strangers? (1=Very hard, 10=Very easy)",
    "How much do you prefer quiet environments? (1=Not at all, 10=Very much)",
    "How often do you reflect on your thoughts and feelings? (1=Rarely, 10=Very often)",
    "How much do you enjoy collaborative work? (1=Dislike, 10=Love)",
    "How comfortable are you in unfamiliar social settings? (1=Very uncomfortable, 10=Very comfortable)",
    "How much do you value close friendships over many acquaintances? (1=Many acquaintances, 10=Close friends)",
    "How often do you feel overwhelmed in noisy environments? (1=Never, 10=Always)",
    "How much do you enjoy spontaneous social plans? (1=Dislike, 10=Love)",
    "How often do you prefer texting over calling? (1=Always call, 10=Always text)",
    "How much do you enjoy brainstorming with others? (1=Dislike, 10=Love)",
    "How often do you feel the need to 'recharge' after socializing? (1=Never, 10=Always)",
    "How much do you enjoy networking events? (1=Dislike, 10=Love)",
    "How often do you prefer reading/hobbies over socializing? (1=Never, 10=Always)",
    "How comfortable are you sharing personal opinions in groups? (1=Very uncomfortable, 10=Very comfortable)",
    "How much do you enjoy leading group activities? (1=Dislike, 10=Love)",
    "How often do you seek out new social experiences? (1=Rarely, 10=Very often)",
    "How much do you enjoy small talk? (1=Dislike, 10=Love)",
    "How often do you feel energized after socializing? (1=Never, 10=Always)",
    "How much do you prefer structured social plans over spontaneous ones? (1=Spontaneous, 10=Structured)",
]

class PersonalityForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for i, label in enumerate(FEATURE_LABELS, start=1):
            self.fields[f'feature_{i}'] = forms.ChoiceField(
                choices=SCALE_CHOICES,
                label=label,
                widget=forms.Select(attrs={'class': 'form-select'})
            )
